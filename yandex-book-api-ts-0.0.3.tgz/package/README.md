# yandex-book-api-ts

> [!WARNING]
> This project is an AI-assisted TypeScript rewrite of [`stepan163s/yandex-book-api`](https://github.com/stepan163s/yandex-book-api/tree/main/yandex_book). It is unofficial and is not affiliated with Yandex.

`yandex-book-api-ts` is an unofficial Yandex Books API client for Node.js, Bun, Deno, and React Native. It provides Promise-based, typed REST and GraphQL operations through `YandexBookClient`.

## TypeScript-only Functions

Additional `YandexBookClient` functions that do not exist in the original Python library will be listed here as they are added.

| Function | Status |
| --- | --- |
| `exportBookQuotes(bookId, format)` | Exports a book's quotes as CSV, Markdown, or HTML content. |

## Requirements

- Node.js 18 or later, Bun, Deno, or React Native
- ESM application code for Node.js, Bun, and Deno

The package uses its bundled `cross-fetch` implementation by default. Browser applications are not supported because Yandex Books' required mobile-client headers and CORS policy cannot be relied on in browsers.

## Installation

```bash
npm install yandex-book-api-ts
```

## Public Usage

Public operations do not require an **OAuth token**. Methods resolve to typed models; resource lookups can resolve to `undefined` when no matching model is returned.

```ts
import { YandexBookClient } from "yandex-book-api-ts";

const client = new YandexBookClient();

const user = await client.getUser("<user-login>");
const books = await client.getUserBooks("<user-login>");
const book = await client.getBook("<book-id>");

if (book) {
  console.log(book.name);
}
```

Other public reads include user audiobooks, comics, bookshelves, followings, impressions, quotes, reading achievements, book impressions, and bookshelf books.

## Authenticated Usage

Provide an **OAuth token** only from your application's secure configuration. The client does not obtain, refresh, or store credentials.

```ts
import { YandexBookClient } from "yandex-book-api-ts";

const token = process.env.YANDEX_BOOKS_OAUTH_TOKEN;

if (!token) {
  throw new Error("YANDEX_BOOKS_OAUTH_TOKEN is required for private operations");
}

const client = new YandexBookClient(token);
const profile = await client.getProfile();
const library = await client.getMyLibrary();
const csv = await client.exportBookQuotes("<book-id>", "csv");
```

Authenticated REST operations include `addBook`, `removeBook`, `getMyBookshelves`, `getReadingAchievements`, `exportBookQuotes`, profile settings, features, notifications, and series following. `exportBookQuotes` accepts `"csv"`, `"markdown"`, or `"html"` and returns only the generated content string.

## Custom Fetch

Pass a fetch-compatible function as the optional second constructor parameter when the application needs custom networking, instrumentation, or a runtime-provided implementation. The client uses the same function for REST and GraphQL requests.

```ts
import { YandexBookClient } from "yandex-book-api-ts";

const client = new YandexBookClient(process.env.YANDEX_BOOKS_OAUTH_TOKEN, async (input, init) => {
  return fetch(input, init);
});
```

Pass `undefined` as the first parameter for public operations with a custom fetch implementation:

```ts
const publicClient = new YandexBookClient(undefined, customFetch);
```

## GraphQL

The client supports typed GraphQL search, subscription, and reading-statistics operations:

```ts
import {
  YandexBookClient,
  type ProfileSubscriptionsQuery,
  type SearchQuery,
  type StatisticsQuery
} from "yandex-book-api-ts";

const client = new YandexBookClient();
const search: SearchQuery = await client.search("<search-query>");

const authenticatedClient = new YandexBookClient(process.env.YANDEX_BOOKS_OAUTH_TOKEN);
const subscriptions: ProfileSubscriptionsQuery = await authenticatedClient.getSubscriptions();
const statistics: StatisticsQuery = await authenticatedClient.getReadingStatistics();
```

The exported **GraphQL contracts** are generated from the versioned documents in `graphql/` and the checked-in `graphql/schema.graphql` snapshot. Regenerate them after an intentional schema or document change with:

```bash
npm run graphql:generate
```

`search` can be used without a token. `getSubscriptions` and `getReadingStatistics` are private operations and require a valid token.

## Release Provenance

- Python parity source revision: [`833b1395efb97f4e871d2b7fdfa524e16a8d4c3b`](https://github.com/stepan163s/yandex-book-api/tree/833b1395efb97f4e871d2b7fdfa524e16a8d4c3b).
- GraphQL schema snapshot: `graphql/schema.graphql`, a reviewed, scoped snapshot of the `Search`, `ProfileSubscriptions`, and `Statistics` operation inputs and selected result fields from that same source revision. It is not a full service introspection schema; see `graphql/README.md` for its review and refresh procedure.

## Error Handling

REST and GraphQL request failures are instances of `ApiError`. Its subclasses are `UnauthorizedError`, `NotFoundError`, and `BadRequestError`. Each error can include a response `status` and safe `details`.

```ts
import {
  ApiError,
  BadRequestError,
  NotFoundError,
  UnauthorizedError,
  YandexBookClient
} from "yandex-book-api-ts";

const client = new YandexBookClient();

try {
  await client.getBook("<book-id>");
} catch (error) {
  if (error instanceof UnauthorizedError) {
    // Supply a valid token for private operations.
  } else if (error instanceof NotFoundError) {
    // The requested resource does not exist.
  } else if (error instanceof BadRequestError) {
    // The request input was rejected.
  } else if (error instanceof ApiError) {
    console.error(error.status, error.details);
  } else {
    throw error;
  }
}
```

## Smoke Tests

Default tests exclude live calls. The opt-in smoke suite makes one public request and one authenticated profile request; it reads only `YANDEX_BOOKS_OAUTH_TOKEN` and skips the live test when that variable is unset or blank.

```bash
YANDEX_BOOKS_OAUTH_TOKEN="<your-token>" npm run test:smoke
```

Do not commit tokens, account data, or live API responses.
